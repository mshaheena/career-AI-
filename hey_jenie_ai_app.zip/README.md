# Instructions to run, deploy and use the app

### Project: Hey Jenie – Your AI Career Assistant
Built with ❤️ for job seekers, students, and professionals worldwide.
